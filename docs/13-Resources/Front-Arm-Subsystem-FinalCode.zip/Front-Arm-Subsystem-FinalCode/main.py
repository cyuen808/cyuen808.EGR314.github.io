# =============================================================================
# Front Arm Subsystem - MERGED (Message Compliance + Articulated Manipulator)
# Caleb Yuen | EGR 314 | Team 202
# Board ID: 'a' (Front Arm)
# UART1: TX=IO43, RX=IO44 (daisy-chain)
# UART0: free for mpremote monitoring (print statements)
#
# Team subsystems:
#   h=HMI, c=Comm, w=Wheel/MQTT, p=Pressure, a=Arm(me), m=Metal, t=Temp, X=Broadcast
#
# HMI sends 4 commands to me (AD:S:U/D/R/L):
#   U = both servos step UP    (shoulder +SHOULDER_STEP, elbow -ELBOW_STEP)
#   D = both servos step DOWN  (shoulder -SHOULDER_STEP, elbow +ELBOW_STEP)
#   R = stepper right STEPS_PER_PRESS
#   L = stepper left  STEPS_PER_PRESS
# Full range: 4 presses U or D takes servos from one extreme to the other.
#
# Telemetry sent after every command: AA (position), AS (status), AE (error).
# AE is always sent — code 0 means "all clear" so HMI display can self-clear.
# =============================================================================

from machine import Pin, PWM, SPI, UART
import time

# =============================================================================
# HARDWARE SETUP
# =============================================================================

# Stepper (DRV8434S via SPI)
STEP   = Pin(14, Pin.OUT)
DIR    = Pin(15, Pin.OUT)
ENABLE = Pin(16, Pin.OUT)
NSLEEP = Pin(9,  Pin.OUT)
NSC    = Pin(10, Pin.OUT)

# RC Servos (PWM @ 50 Hz)
shoulder = PWM(Pin(6), freq=50)
elbow    = PWM(Pin(7), freq=50)
# wrist_servo = PWM(Pin(8), freq=50)   # reserved / not used

# Debug LED
LED = Pin(5, Pin.OUT)
LED.value(1)

# UART1 - daisy-chain network
uart = UART(1, baudrate=9600, tx=Pin(43), rx=Pin(44))

# SPI for DRV8434S
spi = SPI(1, baudrate=500000, polarity=0, phase=1,
          sck=Pin(12), mosi=Pin(11), miso=Pin(13))

# =============================================================================
# SERVO CONSTANTS
# =============================================================================
SHOULDER_MIN  = 900      # down
SHOULDER_MAX  = 1700     # up
SHOULDER_HOME = 1500

ELBOW_MIN  = 1500        # down
ELBOW_MAX  = 1700        # up
ELBOW_HOME = 1900

# Per-press increments (4 presses = full range top to bottom)
SHOULDER_STEP = 200
ELBOW_STEP    = 50

# =============================================================================
# STEPPER CONSTANTS
# =============================================================================
STEPS_PER_PRESS = 100
MIN_POS         = -700
MAX_POS         =  700
STEP_DELAY_MS   = 3

# =============================================================================
# PROTOCOL CONSTANTS
# =============================================================================
MY_ID       = 'a'
PREFIX      = b'AZ'
SUFFIX      = b'YB'
MAX_MSG_LEN = 61
BUF_SIZE    = 128
KNOWN_IDS   = set(['h', 'c', 'w', 'p', 'a', 'm', 't', 'X'])

# =============================================================================
# STATE
# =============================================================================
shoulder_us  = SHOULDER_HOME
elbow_us     = ELBOW_HOME
stepper_pos  = 0
arm_state    = "Idle"
error_code   = 0

rx_buf   = bytearray(BUF_SIZE)
rx_idx   = 0
in_frame = False

send_queue = []

SEND_INTERVAL_MS = 100
last_send_ms     = 0

# =============================================================================
# DRV8434S SPI HELPERS
# =============================================================================
def write_register(addr, data):
    cmd = (0 << 14) | (addr << 9) | data
    buf = bytearray([(cmd >> 8) & 0xFF, cmd & 0xFF])
    NSC.value(0); time.sleep_us(1)
    spi.write(buf)
    time.sleep_us(1); NSC.value(1); time.sleep_us(1)

def read_register(addr):
    cmd = (1 << 14) | (addr << 9)
    buf = bytearray([(cmd >> 8) & 0xFF, cmd & 0xFF])
    result = bytearray(2)
    NSC.value(0); time.sleep_us(1)
    spi.write_readinto(buf, result)
    time.sleep_us(1); NSC.value(1)
    return result

def init_drv8434s():
    NSC.value(1)
    NSLEEP.value(0); time.sleep_ms(10)
    NSLEEP.value(1); time.sleep_ms(200)
    ENABLE.value(1); time.sleep_ms(50)
    write_register(0x06, 0x30); time.sleep_ms(5)   # unlock
    write_register(0x06, 0x80); time.sleep_ms(10)  # clear faults
    fault_check = read_register(0x00)
    if fault_check[1] != 0x00:
        write_register(0x06, 0x80); time.sleep_ms(10)
    write_register(0x04, 0x8F); time.sleep_ms(5)   # enable outputs
    write_register(0x03, 0x80)                      # TRQ_DAC = 50% hold current

def check_drv_fault():
    global error_code
    fault = read_register(0x00)
    if fault[1] != 0x00:
        if   fault[1] & (1 << 3): error_code = 2   # Overcurrent
        elif fault[1] & (1 << 5): error_code = 1   # Stall
        else:                     error_code = 3   # Other
        return True
    return False

# =============================================================================
# SERVO MOTION — synchronous dual-servo (both move together)
# =============================================================================
def write_us(servo, us, min_us, max_us):
    us = max(min_us, min(max_us, us))
    duty = int(us * 65535 / 20000)
    servo.duty_u16(duty)
    return us

def move_both_servos(target_shoulder, target_elbow, step=8, delay_ms=20):
    """Move both servos toward their targets simultaneously."""
    global shoulder_us, elbow_us
    target_shoulder = max(SHOULDER_MIN, min(SHOULDER_MAX, target_shoulder))
    target_elbow    = max(ELBOW_MIN,    min(ELBOW_MAX,    target_elbow))

    while shoulder_us != target_shoulder or elbow_us != target_elbow:
        # shoulder step
        if   shoulder_us < target_shoulder:
            shoulder_us = min(shoulder_us + step, target_shoulder)
        elif shoulder_us > target_shoulder:
            shoulder_us = max(shoulder_us - step, target_shoulder)
        write_us(shoulder, shoulder_us, SHOULDER_MIN, SHOULDER_MAX)

        # elbow step
        if   elbow_us < target_elbow:
            elbow_us = min(elbow_us + step, target_elbow)
        elif elbow_us > target_elbow:
            elbow_us = max(elbow_us - step, target_elbow)
        write_us(elbow, elbow_us, ELBOW_MIN, ELBOW_MAX)

        time.sleep_ms(delay_ms)

# =============================================================================
# STEPPER MOTION — with soft limits + 50% hold current management
# =============================================================================
def move_stepper_clamped(steps, direction):
    """
    Move the stepper `steps` in `direction` (0=right/+, 1=left/-),
    clamped to [MIN_POS, MAX_POS]. Returns actual steps taken.
    Also checks DRV fault periodically and halts on fault.
    """
    global stepper_pos, arm_state, error_code

    # clamp to soft limits BEFORE moving (don't over-travel)
    if direction == 0:  # right/+
        available = MAX_POS - stepper_pos
        if available <= 0:
            print("!! At RIGHT limit ({})".format(MAX_POS))
            error_code = 4  # out-of-range
            return 0
        if steps > available:
            print("!! Clamping {} -> {} (RIGHT limit)".format(steps, available))
            steps = available
            error_code = 4
    else:               # left/-
        available = stepper_pos - MIN_POS
        if available <= 0:
            print("!! At LEFT limit ({})".format(MIN_POS))
            error_code = 4
            return 0
        if steps > available:
            print("!! Clamping {} -> {} (LEFT limit)".format(steps, available))
            steps = available
            error_code = 4

    # Restore full current before stepping
    write_register(0x03, 0x00)
    time.sleep_ms(2)

    DIR.value(direction)
    time.sleep_ms(1)

    arm_state = "Moving"
    for i in range(steps):
        if i % 50 == 0 and check_drv_fault():
            arm_state = "Halted"
            write_register(0x03, 0x80)  # back to 50% hold even on fault
            return i
        STEP.value(1); time.sleep_ms(STEP_DELAY_MS)
        STEP.value(0); time.sleep_ms(STEP_DELAY_MS)

    if direction == 0:
        stepper_pos += steps
    else:
        stepper_pos -= steps

    # Drop back to 50% hold current after move
    write_register(0x03, 0x80)
    return steps

# =============================================================================
# MESSAGE BUILDING
# =============================================================================
def build_packet(sender, receiver, data_str):
    data_str = data_str.replace('AZ', '__').replace('YB', '__')
    if len(data_str) > MAX_MSG_LEN:
        data_str = data_str[:MAX_MSG_LEN]
    pkt = 'AZ' + sender + receiver + data_str + 'YB'
    return pkt.encode() + b'\r\n'

def enqueue_ack(receiver='h'):
    # Report stepper position (main rotation). If HMI wants servo positions
    # too, add AA:SH and AA:EL messages here.
    send_queue.append(build_packet(MY_ID, receiver, 'AA:IL:' + str(stepper_pos) + ';'))

def enqueue_status(receiver='h'):
    send_queue.append(build_packet(MY_ID, receiver, 'AS:S:' + arm_state + ';'))

def enqueue_error(receiver='h'):
    send_queue.append(build_packet(MY_ID, receiver, 'AE:I:' + str(error_code) + ';'))

def enqueue_full_telemetry():
    """Send ack + status + error to HMI after every command.
    AE is always sent — code 0 means 'all clear' so HMI can clear stale errors.
    Wheel ('w') / MQTT bridge lines commented out — re-enable if needed."""
    enqueue_ack('h')
    enqueue_status('h')
    enqueue_error('h')         # always send AE (code 0 = all clear)
    # enqueue_ack('w')         # w = MQTT bridge
    # enqueue_status('w')
    # enqueue_error('w')

# =============================================================================
# MESSAGE PARSER
# =============================================================================
def parse_and_dispatch(raw_bytes):
    raw_bytes = raw_bytes.rstrip(b'\r\n')

    try:
        pkt = raw_bytes.decode('ascii')
    except Exception:
        print("[RX] Malformed: non-ASCII bytes, discarding")
        return

    if not (pkt.startswith('AZ') and pkt.endswith('YB')):
        print("[RX] Malformed: bad prefix/suffix, discarding")
        return

    if len(pkt) < 6:
        print("[RX] Malformed: too short, discarding")
        return

    sender   = pkt[2]
    receiver = pkt[3]
    data     = pkt[4:-2]

    if sender not in KNOWN_IDS:
        print("[RX] Unknown sender '{}', discarding".format(sender))
        return

    if sender == MY_ID:
        print("[RX] Own loopback detected, discarding")
        return

    if len(data) > MAX_MSG_LEN:
        print("[RX] Message data too long ({}), discarding".format(len(data)))
        return

    if receiver != MY_ID and receiver != 'X':
        print("[RX] Not for me (rcvr={}), forwarding".format(receiver))
        uart.write(raw_bytes + b'\r\n')
        return

    print("[RX] For me! sender={} data={}".format(sender, data))
    handle_message(sender, data)

def handle_message(sender, data):
    if data.startswith('AD:S:'):
        handle_drive(data)
    elif data.startswith('PV:'):
        # Placeholder: pressure value from 'p' — TODO when format confirmed
        handle_pressure(data)
    else:
        print("[RX] Unsupported message type: {}".format(data))

def handle_drive(data):
    global arm_state, error_code, shoulder_us, elbow_us
    data = data.rstrip(';')

    if len(data) != 6:
        print("[RX] AD malformed length: '{}'".format(data))
        return

    cmd = data[5]
    if cmd not in ('U', 'D', 'R', 'L'):
        print("[RX] AD unknown command: {}".format(cmd))
        return

    print("[RX] Drive command: {}".format(cmd))
    LED.value(0)
    error_code = 0   # fresh command, clear prior non-fatal errors

    if cmd == 'U':
        # Incremental UP: shoulder goes toward MAX, elbow goes toward MIN
        target_shoulder = shoulder_us + SHOULDER_STEP
        target_elbow    = elbow_us    - ELBOW_STEP
        # Detect already-at-limit for corner-case error flag
        if shoulder_us >= SHOULDER_MAX and elbow_us <= ELBOW_MIN:
            print("!! Servos already at UP limit")
            error_code = 4
        move_both_servos(target_shoulder, target_elbow)
        arm_state = "Done"
    elif cmd == 'D':
        # Incremental DOWN: shoulder goes toward MIN, elbow goes toward MAX
        target_shoulder = shoulder_us - SHOULDER_STEP
        target_elbow    = elbow_us    + ELBOW_STEP
        if shoulder_us <= SHOULDER_MIN and elbow_us >= ELBOW_MAX:
            print("!! Servos already at DOWN limit")
            error_code = 4
        move_both_servos(target_shoulder, target_elbow)
        arm_state = "Done"
    elif cmd == 'R':
        taken = move_stepper_clamped(STEPS_PER_PRESS, 0)
        arm_state = "Halted" if arm_state == "Halted" else "Done"
    elif cmd == 'L':
        taken = move_stepper_clamped(STEPS_PER_PRESS, 1)
        arm_state = "Halted" if arm_state == "Halted" else "Done"

    LED.value(1)
    enqueue_full_telemetry()

def handle_pressure(data):
    """Placeholder for pressure-close feedback loop.
    TODO: once 'p' confirms format, parse value and implement threshold halt."""
    print("[RX] Pressure data received (handler stubbed): {}".format(data))

# =============================================================================
# UART RX — non-blocking byte-by-byte frame accumulator
# =============================================================================
def rx_tick():
    global rx_buf, rx_idx, in_frame

    while uart.any():
        b = uart.read(1)
        if b is None:
            break
        ch = b[0]

        if not in_frame:
            if ch == ord('A'):
                rx_idx = 0
                rx_buf[rx_idx] = ch
                rx_idx += 1
            elif rx_idx == 1 and ch == ord('Z'):
                rx_buf[rx_idx] = ch
                rx_idx += 1
                in_frame = True
            else:
                rx_idx = 0
            continue

        if rx_idx >= BUF_SIZE:
            print("[RX] Buffer overflow, discarding frame")
            rx_idx = 0
            in_frame = False
            continue

        rx_buf[rx_idx] = ch
        rx_idx += 1

        if rx_idx >= 4 and rx_buf[rx_idx-2] == ord('Y') and rx_buf[rx_idx-1] == ord('B'):
            raw = bytes(rx_buf[:rx_idx])
            in_frame = False
            rx_idx = 0
            parse_and_dispatch(raw)

# =============================================================================
# UART TX — rate-limited send from queue
# =============================================================================
def tx_tick():
    global last_send_ms
    if not send_queue:
        return
    now = time.ticks_ms()
    if time.ticks_diff(now, last_send_ms) < SEND_INTERVAL_MS:
        return
    pkt = send_queue.pop(0)
    uart.write(pkt)
    last_send_ms = time.ticks_ms()
    print("[TX] Sent: {}".format(pkt))

# =============================================================================
# DEMO SENDER — cycles all 3 message types (for Message Compliance demo)
# Keep available for checkoff demonstration of all message variants.
# =============================================================================
demo_cycle    = 0
last_demo_ms  = 0
DEMO_ENABLED  = False        # set True to enable periodic demo sends
DEMO_INTERVAL = 3000

def demo_tick():
    global demo_cycle, last_demo_ms
    if not DEMO_ENABLED:
        return
    now = time.ticks_ms()
    if time.ticks_diff(now, last_demo_ms) < DEMO_INTERVAL:
        return
    last_demo_ms = now

    variant = demo_cycle % 3
    if variant == 0:
        pos = (demo_cycle // 3 % 5) * 100 - 200
        send_queue.append(build_packet(MY_ID, 'h', 'AA:IL:' + str(pos) + ';'))
        print("[DEMO] Queued AA:IL:{}".format(pos))
    elif variant == 1:
        states = ["Idle", "Moving", "Done", "Halted"]
        s = states[(demo_cycle // 3) % len(states)]
        send_queue.append(build_packet(MY_ID, 'h', 'AS:S:' + s + ';'))
        print("[DEMO] Queued AS:S:{}".format(s))
    else:
        ec = (demo_cycle // 3) % 4
        send_queue.append(build_packet(MY_ID, 'h', 'AE:I:' + str(ec) + ';'))
        print("[DEMO] Queued AE:I:{}".format(ec))

    demo_cycle += 1

# =============================================================================
# STARTUP
# =============================================================================
print("=== Front Arm Subsystem Booting ===")
print("Board ID: '{}'".format(MY_ID))
print("UART1: TX=IO43, RX=IO44 (daisy-chain)")

# Servos to HOME on boot
write_us(shoulder, SHOULDER_HOME, SHOULDER_MIN, SHOULDER_MAX)
write_us(elbow,    ELBOW_HOME,    ELBOW_MIN,    ELBOW_MAX)
print("Servos -> HOME (shoulder={}, elbow={})".format(SHOULDER_HOME, ELBOW_HOME))

# Stepper driver init (includes 50% hold current)
init_drv8434s()
fault = read_register(0x00)
ctrl2 = read_register(0x04)
print("FAULT reg: {} | CTRL2 reg: {}".format(hex(fault[1]), hex(ctrl2[1])))
if fault[1] == 0x00:
    print("DRV8434S: OK — hold current at 50%")
else:
    print("DRV8434S: FAULT - check power/wiring")
    error_code = 3

# Blink 3x = ready
for _ in range(3):
    LED.value(0); time.sleep_ms(150)
    LED.value(1); time.sleep_ms(150)

print("=== Ready. Listening on UART1 ===")

# =============================================================================
# MAIN LOOP
# =============================================================================
while True:
    rx_tick()
    tx_tick()
    demo_tick()